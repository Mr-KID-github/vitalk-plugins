# @vitalk/plugin-sdk

ViTalk 页面插件的公开 SDK。整个 npm 包无运行时依赖，源码只依赖标准浏览器／JavaScript API；不导入宿主源码、Tauri 或私有路径。可在独立 Git 仓库开发、构建、测试、打包，当前尚未公开发布 npm。

```sh
npm install
npm test
npm pack
```

复制项目后独立 `git init`，通过 tgz 安装 SDK 即可构建插件。包只包含 dist/ 和说明；不包含 ViTalk 内部代码或密钥。

## 接入

```ts
import {createPluginClient, createWindowTransport} from '@vitalk/plugin-sdk';
const client = createPluginClient(createWindowTransport(token));
const page = await client.history.list({scope: 'all', limit: 20});
const reply = await client.ai.generate({
  messages: [{role:'user', content:'请总结以下表达…'}],
  temperature: 0.3, maxOutputTokens: 1000, thinkingMode: 'default'
});
await client.storage.set({key:'review',value:reply.text});
client.dispose();
```

`token` 来自宿主注入的 `window.__VITALK_PLUGIN_TOKEN__`，是页面会话令牌，不能自行生成、保存或传给其他页面。沙箱页面通过 `window.parent.postMessage` 通信，响应必须来自 parent、通道与令牌匹配。请求／响应均采用 `vitalk-plugin/v1`。

| 方法 | 参数与结果 |
|---|---|
| host.info | 无参数 → appVersion、sdkVersion、pluginId |
| history.list | scope: own/all、limit、cursor、query、from/to（毫秒） → items、nextCursor |
| history.append | text、mode → HistoryRecord（ID、pluginId、时间由宿主生成） |
| storage.get | key → `{value}`（value 为 JsonValue 或 null） |
| storage.set | key、value → ok:true |
| storage.delete | key → ok:true |
| ai.generate | messages、model、temperature、maxOutputTokens、thinkingMode → text |
| speech.transcribe | bytes（number[]）、mimeType、language → text |
| clipboard.writeText | text（非空、最多64 KiB UTF-8）→ ok:true |

历史写入需 `history.write`，记录归属由宿主设置，不能伪造其他插件身份。own 是本插件产生的记录，读取无需额外权限；all 读取才需 `history.read`，它是用户授权可读取的 ViTalk 原生语音会话历史（包含 English 表达），不合并插件自身创建的记录；游标由宿主提供，插件原样传回，不解析它。存储自动限定为调用插件的空间，无权跨插件读写。

每个插件空间（包含自身历史）总额最多 500 KB，由宿主校验。模型与语音服务配置／认证由宿主管理。model 第一版只支持宿主默认模型（省略或 `default`）；thinkingMode 是 `default/on/off/low/medium/high`，实际支持由宿主和模型决定。

`clipboard.writeText({text})` 需要 `clipboard.write` 权限，由宿主执行系统复制；保留原始空格和换行，不暴露剪贴板读取。仅在返回 `{ok:true}` 后显示复制成功；系统失败返回 `clipboard_error`，页面可以提示手动复制。旧宿主不支持此新增方法时返回 `unsupported_method`。

每个方法最后可传 `{signal: AbortSignal, timeoutMs: number}`，默认等待最多 60 秒。调用失败抛出包含 `code/message` 的 PluginError；保留宿主经脱敏的错误。AbortSignal、超时和 dispose 取消本地等待、释放监听及计时器；目前没有远端 cancel 消息，不保证已经提交的模型／语音工作停止。

关闭／停用后宿主拒绝新调用并丢弃迟到响应，不保证远端模型或语音请求停止。模型宿主超时90秒，语音120秒；建议分别传 `timeoutMs: 100_000` 或 `130_000`，避免SDK默认60秒先超时。

自定义 transport 必须提供 `sessionToken/send/subscribe`，可选 dispose；适合测试，不赋予宿主权限。client.dispose 会同时 dispose 此 transport，因此一个 transport 应只配一个 client。

## 包与版本

`PluginPackage` 为 `{format:'vitalk-plugin/v1',manifest,html}`，文件扩展名 `.vitalk-plugin.json`。manifest 包含 id/name/version/sdkVersion/description/permissions/page.title。

id 使用组织命名，例如 `community.expression-review`；版本支持三段数字和预发行后缀，当前不支持 +build。标题／名称上限 80 字符，描述上限 1000，整个 UTF-8 JSON 包上限 2 MB。validatePluginPackage 可在构建时提前检查；宿主仍必须再次严格校验，并检查 CSP、授权和存储边界。

npm SDK 版本目前为 0.3.0，消息 API 与 manifest sdkVersion 均为 1。SDK 新增向后兼容辅助功能不改变协议；不兼容协议升级须使用新的 sdkVersion，并先取得宿主支持。插件自身 version 不等同 SDK/API 版本。

第一阶段采用宿主隔离 WebView 页面；HTML、JS、样式全部内联。iframe与CSP限制常规资源加载、fetch等能力，但无法全面阻止页面通过自身导航向外站携带数据；当前仅支持可信本地插件，不声称完全禁止网络外传。不提供 CLI/Node 执行、流式模型事件、后台任务或语音模式注册的伪接口。未来可以另行设计，但本轮插件不能依赖这些能力。

## 完整 English 工作空间（0.3.0）

公开 `sdk.english` 保留原页面 20 个方法。参数统一为对象，字段与原 client 一致。DTO 从 SDK 导出，完整定义见 `dist/english.d.ts`。所有请求可传 `signal` 和 `timeoutMs`，本地取消不保证撤销已提交的原生或云端操作。

```ts
const preferences = await sdk.english.preferences({});
const records = await sdk.english.records({ search: "", limit: 20, offset: 0 });
await sdk.english.revise({ sessionId, expectedRevision, transcript });
```

| 权限 | 公开能力 | 数据来源 |
|---|---|---|
| `english.workspace` | 原 English 记录、复盘、成长数据、词汇、查词、修订、设置和原音频 | 宿主既有数据库和服务 |
| `talkingo.read` | `readGoals`、`readMobileStatus` | 当前宿主账号授权的云端数据 |
| `talkingo.write` | `publishSource`、`approveTeaching`、`withdrawSource` | 当前宿主账号授权的固定云端操作 |

`account.snapshot({})` 需上述任一权限，只返回 `status`、`userId`、`configReady`。插件无法取得账号 token、云端 URL 或密钥，不能传入自选 URL、token 或原生命令。

```ts
const account = await sdk.account.snapshot({});
await sdk.talkingo.publishSource({
  ownerId: account.userId!,
  record: { sessionId, revision, finalText, createdAt },
  context: "工作交流",
  confirmed: true,
});
```

发布和教学批准均由宿主再次查询原记录，核对当前 revision、文本、时间及处理状态。`approveTeaching` 还要求原 `TeachingDraft`、UUID `requestId` 和明确确认，返回服务确认的教学版本号。撤回保留 `ownerId`、`sessionId`、`confirmed:true`；删除或更新本地记录后，用户仍能撤回自己的云端资料。账号代次变化会阻断旧请求，令牌只用于宿主内部 gateway。

| 原方法 | SDK 方法 |
|---|---|
| teachingDraft、lookup、saveLookup、savedLookups | `english` 下同名方法 |
| clarify、retranscribe、originalAudio、dailyReview、analyze、revise、correct | `english` 下同名方法 |
| preferences、setEnabled、setStoragePreferences、setPreferences | `english` 下同名方法 |
| records、vocabulary、vocabularySources、setVocabularyState、deleteRecord | `english` 下同名方法 |

`retranscribe` 返回 `{ok:true}` 或 `null`，不返回原生 Session 的诊断或 provider 信息。`host.info()` 可返回宿主语言 `language`。iframe 继续禁止网络连接，仅允许原音频 `blob:` 和字体 `data:` 资源。受信 English 包还受安装状态和原生功能启用状态约束；社区插件声明公开权限不会变为受信功能包。
